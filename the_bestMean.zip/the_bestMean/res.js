import { Module } from "module";

 class ResponseMst{
    res;
}
module.exports = ResponseMst;