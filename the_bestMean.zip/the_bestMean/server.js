
var express = require('express');
var bodyParser = require('body-parser');
var cors = require('cors');
var app = express();
var mongoose = require('mongoose');
var product = require('./product');
var nodemailer = require('nodemailer'); 
/* var response = require('./res'); */
var ps=require('./src/app/service/patientService');
// Instantiate User:

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
var port = process.env.PORT || 8090;
var router = express.Router();
mongoose.connect('mongodb://localhost:27017/products');

// all other code will go here 


app.use(cors());
app.use('/', router);
app.listen(port);
console.log('REST API is runnning at ' + port);
/* var t=new test();
t.sayHi();
var pService=new ps();
pService.sayHi(7);
 */
/* var response=new response(); */
//api ==1faa2fec
//secret==wL8salQR94B4KHev

const SendOtp = require('sendotp');
//const sendOtp = new SendOtp('MSG91');
const sendOtp = new SendOtp('MSG91', 'Otp for your order is {{otp}}, please do not share it with anybody');
const Nexmo = require('nexmo');
const nexmo = new Nexmo({
  apiKey:'1faa2fec',
  apiSecret:'wL8salQR94B4KHev'
});



router.route('/sms').get(function (req, res) {
   console.log("====sms");
    nexmo.message.sendSms(
        '919932472519', '918076410287', 'Ka Govind Babu-- gablu da here',
          (err, responseData) => {
            if (err) {
              console.log(err);
              res.send({res:'Not ok'});
            } else {
                res.send({res:'ok'});
              console.dir(responseData);
            }
          }
       );

});

router.route('/otp').get(function (req, res) {
    console.log("====otp");
    sendOtp.send("918076410287", "PRIIND", "4635", function (error, data) {
        
         console.log(data);
        if (error) {
            res.send({res:'not ok'});
        }
        res.send({res:'ok'});
      });
 
 });


router.route('/products').post(function (req, res) {
     var p = new product();
     console.log("====saving");
    p.title = req.body.title;
    p.price = req.body.price;
    p.instock = req.body.instock;
    p.photo = req.body.photo;
    p.save(function (err) {
        if (err) {
            res.send({res:'not ok'});
        }
        res.send({res:'ok'});
    })
 });

 router.route('/email').get(function (req, res) {
        console.log("testing Email");
        var transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
              user: 'biswassomnath39@gmail.com',
              pass: 'somnathbiswas@123'
            }
          });
          
          var mailOptions = {
            from: 'biswassomnath39@gmail.com',
            to: 'govind.contact@gmail.com',
            subject: 'Sending Email....',
            text: 'ok'
          };
          
          transporter.sendMail(mailOptions, function(error, info){
            if (error) {
              console.log(error);
                res.send({res:'not ok'});
             } else {
                res.send({res:'ok'});
              console.log('Email sent: ' + info.response);
            }
          });
       
});



router.route('/products').get(function (req, res) {
   
     /*  product.find(function (err, products) {
        if (err) {
            res.send(err);
        }
        res.send(products);
    });  */ 

    console.log("====fetching");


});

router.route('/products/:product_id').get(function (req, res) {


    product.findById(req.params.product_id, function (err, prod) {
        if (err)
            res.send(err);
        res.json(prod);
    });
});

router.route('/products/:product_id').put(function (req, res) {

    product.findById(req.params.product_id, function (err, prod) {
        if (err) {
            res.send(err);
        }
        prod.title = req.body.title;
        prod.price = req.body.price;
        prod.instock = req.body.instock;
        prod.photo = req.body.photo;
        prod.save(function (err) {
            if (err)
                res.send(err);

            res.json({ message: 'Product updated!' });
        });

    });
});

router.route('/products/:product_id').delete(function (req, res) {

    product.remove({ _id: req.param.product_id }, function (err, prod) {
        if (err) {
            res.send(err);
        }
        res.json({ message: 'Successfully deleted' });
    })

});
