class PS {
    //...
    constructor(name) {
        this.name = name;
      }
    
      sayHi(num) {
          num=num+3;
        console.log("ok"+num);
      }
    
};

module.exports = PS;
