export class ProductMst {
    title: String;
    price: Number;
    instock: Boolean;
    photo: String;
 }

 