import { Injectable, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Http } from '@angular/http';
import { ResponseMst } from './res';
import { ProductMst } from './Product.model';
import 'rxjs';
import { HttpClient } from '@angular/common/http';
@Injectable()
export class ProductService {

  url: string;
  constructor(private nativeHttp: Http, private http: HttpClient) {

  }
  saveProduct(pMst: ProductMst): Observable<ResponseMst> {
    this.url = "http://localhost:8090/products";

    //return this.nativeHttp.post(this.url,pMst).map(res => res.json());

    return this.http.post<ResponseMst>(this.url, pMst);
  }

  getProducts(): Observable<ProductMst[]> {
    this.url = "http://localhost:8090/products";

    //return this.nativeHttp.post(this.url,pMst).map(res => res.json());

    return this.http.get<ProductMst[]>(this.url);
  }
  ///products/email
  sendEmail(pMst: ProductMst): Observable<ResponseMst> {
    alert("======sms");
        //this.url = "http://localhost:8090/email";
        //this.url = "http://localhost:8090/sms";
        this.url = "http://localhost:8090/otp";
            
    //return this.nativeHttp.post(this.url,pMst).map(res => res.json());

    return this.http.get<ResponseMst>(this.url);
  }
}



/* export class ProductService {

  constructor() {

  }
  getUserDetails() {
     if(userMst.password=="somnath"){
       alert("welcome");
     }else{
       alert("sorry");
     }
  }
} */