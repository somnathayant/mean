import { Component, OnInit } from '@angular/core';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { ProductMst } from './Product.model';
import { ProductService } from './productService';
@Component({
  selector: 'app-root',
  templateUrl: './product.html',
  providers: [ProductService]

})
export class AppComponent implements OnInit {

  productForm: FormGroup;
  pArry:ProductMst[] = [];
  constructor(private fb: FormBuilder, private productService: ProductService) {

  }
  ngOnInit() {
    this.productForm = this.fb.group({
      'title': new FormControl('', Validators.compose([Validators.required])),
      'price': new FormControl('')

    });
  }

  saveProduct(pMst:ProductMst) {
    /* pMst.instock=true;
    pMst.photo=null;
    alert("go")
    this.productService.saveProduct(pMst).subscribe((data) => {
      if(data.res=="ok"){
        alert("product saved");
      }
    },
      err => {

      },
      () => { console.log('Method Executed') }
    );    
  */
     /*   this.productService.getProducts().subscribe((data) => {
      this.pArry=data;
      alert(this.pArry[0].price);
    },
      err => {

      },
      () => { console.log('Method Executed') }
    );  */
   
      //sending email
     // this.productService.sendEmail();

     /*  this.productService.sendEmail(pMst).subscribe((data) => {
        if(data.res=="ok"){
          alert("Email sent");
        }
      },
        err => {
  
        },
        () => { console.log('Method Executed') }
      );   
  } */
  this.productService.sendEmail(pMst).subscribe((data) => {
    if(data.res=="ok"){
      alert("sms sent");
    }
  },
    err => {

    },
    () => { console.log('Method Executed') }
  );   
}


}