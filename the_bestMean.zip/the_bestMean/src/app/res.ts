export class ResponseMst{
    res:string;
}