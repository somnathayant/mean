class Test {
    //...
    constructor(name) {
        this.name = name;
      }
    
      sayHi() {
        console.log("ok");
      }
    
};

module.exports = Test;

